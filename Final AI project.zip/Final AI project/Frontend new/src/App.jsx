import React, { useState } from 'react';
import './App.css';

function App() {
  const [range, setRange] = useState({ min: '', max: '' });
  const [songs, setSongs] = useState([]);
  const [csv, setCsv] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleFile = (e) => setCsv(e.target.files[0]);

  const handleSuggest = async () => {
    if (!range.min || !range.max || !csv) return alert("Fill all fields and upload mp3 or wav.");

    const formData = new FormData();
    formData.append("min", range.min);
    formData.append("max", range.max);
    formData.append("csv", csv);

    try {
      setLoading(true);
      const res = await fetch("http://127.0.0.1:5000/suggest", {
        method: "POST",
        body: formData
      });
      const data = await res.json();
      setSongs(data.songs);
    } catch (error) {
      console.error("Error fetching suggestions:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="app">
      <h1>🎤 AI Karaoke Song Suggester</h1>
      <input type="number" placeholder="Min pitch (Hz)" onChange={(e) => setRange({ ...range, min: e.target.value })} />
      <input type="number" placeholder="Max pitch (Hz)" onChange={(e) => setRange({ ...range, max: e.target.value })} />
      <input type="file" accept=".mp3, .wav" onChange={handleFile} />
      <button onClick={handleSuggest} disabled={loading}>
        {loading ? "Loading..." : "Suggest Songs"}
      </button>

      <h2>Suggestions:</h2>
      <ul>
        {songs.map((s, i) => <li key={i}>{s.title} — {s.artist}</li>)}
      </ul>
    </div>
  );
}

export default App;
