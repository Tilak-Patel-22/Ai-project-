import pygame
import sounddevice as sd
import numpy as np
import soundfile as sf
import librosa
import pandas as pd

def play_mp3(file_path):
    pygame.mixer.init()
    pygame.mixer.music.load(file_path)
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        continue

def record_audio(duration=10, samplerate=44100):
    print(f"Recording for {duration} seconds. Sing your range...")
    audio = sd.rec(int(duration * samplerate), samplerate=samplerate, channels=1, dtype='float32')
    sd.wait()
    print("Done recording!")
    sf.write('test_output.wav', audio, samplerate)
    return np.ravel(audio)

def detect_pitch(audio, samplerate):
    pitches, magnitudes = librosa.piptrack(y=audio, sr=samplerate)
    pitch_values = [pitches[i, j] for i in range(pitches.shape[0]) for j in range(pitches.shape[1]) if pitches[i, j] > 0]
    return pitch_values

def suggest_songs(user_min, user_max, csv_path):
    songs = pd.read_csv(csv_path, encoding='ISO-8859-1')
    songs['lowest_note'] = pd.to_numeric(songs['lowest_note'], errors='coerce')
    songs['highest_note'] = pd.to_numeric(songs['highest_note'], errors='coerce')
    songs = songs.dropna(subset=['lowest_note', 'highest_note'])
    matching = songs[(songs['lowest_note'] >= user_min) & (songs['highest_note'] <= user_max)]
    return matching[['title', 'artist']]

if __name__ == "__main__":
    samplerate = 44100
    audio = record_audio(duration=10, samplerate=samplerate)
    pitches = detect_pitch(audio, samplerate)

    if pitches:
        min_pitch = min(pitches)
        max_pitch = max(pitches)
        print(f"Detected vocal range: {min_pitch:.2f} Hz to {max_pitch:.2f} Hz")
        results = suggest_songs(min_pitch, max_pitch, 'songs_mp3.csv')
        if not results.empty:
            print("\n🎤 Songs within your vocal range:")
            print(results)
        else:
            print("😕 No songs match your vocal range. Try again or sing more notes.")
    else:
        print("No pitch detected. Try again.")