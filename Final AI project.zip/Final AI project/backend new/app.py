from flask import Flask, request, jsonify
from vocal_range_detector import record_audio, detect_pitch, suggest_songs
from flask_cors import CORS  # ⬅️ Import this

app = Flask(__name__)
CORS(app)

@app.route('/', methods=['GET'])
def home():
    return '''
    <h1>🎤 AI Karaoke Suggester Backend</h1>
    <p>Server is running. Use the /suggest endpoint to POST data from frontend.</p>
    '''


@app.route('/suggest', methods=['POST'])
def suggest():
    audio = record_audio(duration=5)
    pitches = detect_pitch(audio, 44100)

    if pitches:
        min_pitch = min(pitches)
        max_pitch = max(pitches)
        songs_df = suggest_songs(min_pitch, max_pitch, 'songs_mp3.csv')
        songs = songs_df.to_dict(orient='records')
        return jsonify({
    'range': [float(min_pitch), float(max_pitch)],
    'songs': songs
})

    else:
        return jsonify({'error': 'No pitch detected'}), 400

if __name__ == '__main__':
    
    print("🎤 Flask server starting...")

    app.run(debug=True)
